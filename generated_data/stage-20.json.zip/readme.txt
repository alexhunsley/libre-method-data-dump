This data was produced by the Libre Method tool (https://github.com/alexhunsley/libre-method-json-place-notation).

It produces data by modifying data that is Copyright Anthony P. Smith (http://www.methods.org.uk), whose full attribution is as follows:

```
These method collections are the copyright of Anthony P. Smith. You are welcome to make copies of the
material for your own use. You may distribute copies to others provided that you do not do so for profit
and provided that you include this copyright statement. If you modify the material before distributing it,
you must include a clear notice that the material has been modified.
```
